# MoraMaps
Android map of important locations in university of Moratuwa.

This is a an android app developed using google maps api to help students find important locations within the university. It will support all android devices running ICS or later.
